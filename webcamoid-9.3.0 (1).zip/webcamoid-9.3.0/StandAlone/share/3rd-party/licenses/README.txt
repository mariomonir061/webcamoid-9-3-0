This folder contains licences for 3rd-party work incorporated into Webcamoid.
These licences DOES NOT applies to Webcamoid itself.
