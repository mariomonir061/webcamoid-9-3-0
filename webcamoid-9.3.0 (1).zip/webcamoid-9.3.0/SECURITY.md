# Security Policy

## Supported Versions

Only report vulnerabilities in the [latest stable](https://github.com/webcamoid/webcamoid/releases) version and the [master repository](https://github.com/webcamoid/webcamoid) (that includes [daily build](https://bintray.com/webcamoid/webcamoid/webcamoid/daily/link)).

## Reporting a Vulnerability

Report all vulnerabilities at the [issues section](https://github.com/webcamoid/webcamoid/issues).
